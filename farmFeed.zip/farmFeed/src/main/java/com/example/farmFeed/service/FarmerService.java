package com.example.farmFeed.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.farmFeed.entity.Farmer;
import com.example.farmFeed.repository.FarmerRepository;
import java.util.Optional;

@Service
public class FarmerService {

    @Autowired
    private FarmerRepository repository;

    /**
     * Sign up a new farmer
     */
    public Farmer save(Farmer farmer) {
        return repository.save(farmer);
    }

    /**
     * Login farmer with email and password
     */
    public Optional<Farmer> login(String email, String password) {
        return repository.findByEmailAndPassword(email, password);
    }

    /**
     * Find farmer by email
     */
    public Optional<Farmer> findByEmail(String email) {
        return repository.findByEmail(email);
    }
}

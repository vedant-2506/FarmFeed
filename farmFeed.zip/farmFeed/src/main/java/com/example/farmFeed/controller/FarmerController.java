package com.example.farmFeed.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.farmFeed.entity.Farmer;
import com.example.farmFeed.service.FarmerService;
import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/Farmer")
public class FarmerController {

    @Autowired
    private FarmerService service;

    /**
     * POST /api/Farmer/SignUp - Register a new farmer
     */
    @PostMapping("/SignUp")
    public ResponseEntity<?> SignUp(@RequestBody Farmer farmer) {
        try {
            // Check if email already exists
            Optional<Farmer> existing = service.findByEmail(farmer.getEmail());
            if (existing.isPresent()) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Email already registered"));
            }

            Farmer savedFarmer = service.save(farmer);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Sign up successful",
                "farmer_id", savedFarmer.getId(),
                "email", savedFarmer.getEmail()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * POST /api/Farmer/Login - Login farmer
     */
    @PostMapping("/Login")
    public ResponseEntity<?> Login(@RequestBody Map<String, String> credentials) {
        try {
            String email = credentials.get("email");
            String password = credentials.get("password");

            if (email == null || password == null) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Email and password required"));
            }

            Optional<Farmer> farmer = service.login(email, password);

            if (farmer.isPresent()) {
                Farmer f = farmer.get();
                return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Login successful",
                    "farmer_id", f.getId(),
                    "email", f.getEmail(),
                    "name", f.getName() != null ? f.getName() : "Farmer"
                ));
            } else {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid email or password"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", e.getMessage()));
        }
    }
}


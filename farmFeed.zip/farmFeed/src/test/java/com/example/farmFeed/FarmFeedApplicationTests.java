package com.example.farmFeed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmFeedApplicationTests {

	@Test
	void contextLoads() {
	}

}

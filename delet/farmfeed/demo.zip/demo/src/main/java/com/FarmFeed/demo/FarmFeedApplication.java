package com.FarmFeed.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmFeedApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmFeedApplication.class, args);
	}

}
